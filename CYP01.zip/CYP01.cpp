#include <stdio.h>

int main()
{

	int pixel_ancho, pixel_alto, Xizq, Yizq, Xder, Yder;

	float porcentajeX, porcentajeY, porcentaje_ancho, porcenjate_alto;

	scanf_s("%i", &pixel_ancho);

	scanf_s("%i", &pixel_alto);

	scanf_s("%f", &porcentajeX);

	scanf_s("%f", &porcentajeY);

	scanf_s("%f", &porcentaje_ancho);

	scanf_s("%f", &porcenjate_alto);

	Xizq = porcentajeX * pixel_ancho;
	Yizq = porcentajeY * pixel_alto;
	Xder = pixel_ancho * porcentaje_ancho + Xizq;
	Yder = pixel_alto * porcenjate_alto + Yizq;

	printf("%i %i %5.2f %5.2f %5.2f %5.2f %i %i %i %i", pixel_ancho, pixel_alto, porcentajeX, porcentajeY, porcentaje_ancho, porcenjate_alto, Xizq, Yizq, Xder, Yder);


}
